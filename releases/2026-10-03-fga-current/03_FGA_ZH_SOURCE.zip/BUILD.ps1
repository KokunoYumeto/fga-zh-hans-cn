param([ValidateSet('native','direct')][string]$SourceForm='native',[Parameter(Mandatory=$true)][string]$OutputDirectory,[string]$XeLaTeXPath='')
$ErrorActionPreference='Stop'
$packageRoot=$PSScriptRoot
$outputRoot=[IO.Path]::GetFullPath($OutputDirectory)
if(Test-Path -LiteralPath $outputRoot){throw 'Preserve prior build evidence: use a new output directory.'}
$manifest=Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'MANIFEST.json')|ConvertFrom-Json
foreach($entry in $manifest.files){
 $p=Join-Path $packageRoot $entry.path
 if((Get-Item -LiteralPath $p).Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $p).Hash -ne $entry.sha256){throw "Source pin mismatch: $($entry.path)"}
}
$engine=if($XeLaTeXPath){[IO.Path]::GetFullPath($XeLaTeXPath)}else{(Get-Command xelatex -ErrorAction Stop).Source}
if(-not(Test-Path -LiteralPath $engine)){throw 'XeLaTeX unavailable'}
$guard=Join-Path $packageRoot 'build_support/run_guarded_process.ps1'
$mutex=[Threading.Mutex]::new($false,'Global\InterlanguageTeXSlotV1')
$owned=$false;$abandoned=$false;$failure=$null;$passes=@();$saved=@{}
foreach($v in 'TEMP','TMP','SOURCE_DATE_EPOCH','FORCE_SOURCE_DATE','TZ','MIKTEX_ENABLE_INSTALLER'){$saved[$v]=[Environment]::GetEnvironmentVariable($v,'Process')}
try{
 try{$owned=$mutex.WaitOne(1000)}catch [Threading.AbandonedMutexException]{$owned=$true;$abandoned=$true}
 if(-not $owned){throw 'TeX mutex occupied; no worker launched. Continue non-TeX assembly.'}
 [IO.Directory]::CreateDirectory($outputRoot)|Out-Null
 $temp=Join-Path $outputRoot 'tmp';[IO.Directory]::CreateDirectory($temp)|Out-Null
 $env:TEMP=$temp;$env:TMP=$temp;$env:SOURCE_DATE_EPOCH='1791028800';$env:FORCE_SOURCE_DATE='1';$env:TZ='UTC';$env:MIKTEX_ENABLE_INSTALLER='0'
 foreach($edition in 'primary','replay'){
  $root=Join-Path $outputRoot $edition
  foreach($entry in $manifest.files|Where-Object{$_.path.StartsWith("$SourceForm/")}){
   $relative=$entry.path.Substring($SourceForm.Length+1);$dest=Join-Path $root $relative
   [IO.Directory]::CreateDirectory((Split-Path -Parent $dest))|Out-Null
   [IO.File]::Copy((Join-Path $packageRoot $entry.path),$dest,$false)
  }
  $work=if($SourceForm -eq 'native'){Join-Path $root 'zh'}else{$root}
  $body=if($SourceForm -eq 'native'){'main.tex'}else{'02_FGA_ZH_CURRENT.tex'}
  foreach($pass in 1..5){
   $rp=Join-Path $work "pass$pass.guard.json"
   & $guard -FilePath $engine -ArgumentList @('-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder','-jobname=FGA_ZH_CURRENT',$body) -WorkingDirectory $work -TaskRoot $outputRoot -ReceiptPath $rp -TimeoutSeconds 1200|Out-Null
   $g=Get-Content -Raw -LiteralPath $rp|ConvertFrom-Json
   if($g.status -ne 'SUCCEEDED' -or $g.cap_triggered -or $g.final_active_processes -ne 0 -or $g.memory_limit_bytes -ne 3221225472){throw 'Captured worker failure'}
   $passes+=@{edition=$edition;pass=$pass;receipt=$rp;peak_bytes=$g.peak_job_memory_used_bytes}
   Write-Output "$SourceForm $edition pass$pass complete"
   if($pass -eq 4){[IO.File]::Copy((Join-Path $work 'FGA_ZH_CURRENT.pdf'),(Join-Path $work 'pass4.pdf'),$false)}
  }
  $log=[IO.File]::ReadAllText((Join-Path $work 'FGA_ZH_CURRENT.log'))
  if($log -match '(?im)^Missing character:|undefined references|Reference .+ undefined|Citation .+ undefined|Rerun to get cross-references right|multiply[- ]defined labels|^![ \t]*\S'){throw "Terminal log failure: $edition"}
  if((Get-FileHash -LiteralPath (Join-Path $work 'FGA_ZH_CURRENT.pdf')).Hash -ne (Get-FileHash -LiteralPath (Join-Path $work 'pass4.pdf')).Hash){throw 'Pass4/5 PDF bytes differ; retain evidence and diagnose.'}
 }
 $rel=if($SourceForm -eq 'native'){'zh/FGA_ZH_CURRENT.pdf'}else{'FGA_ZH_CURRENT.pdf'}
 if((Get-FileHash -LiteralPath (Join-Path $outputRoot "primary/$rel")).Hash -ne (Get-FileHash -LiteralPath (Join-Path $outputRoot "replay/$rel")).Hash){throw 'Primary/replay PDF bytes differ'}
}catch{$failure=$_.Exception.Message}
finally{
 if($owned){$mutex.ReleaseMutex()};$mutex.Dispose()
 foreach($v in $saved.Keys){[Environment]::SetEnvironmentVariable($v,$saved[$v],'Process')}
 [IO.Directory]::CreateDirectory($outputRoot)|Out-Null
 $r=@{source_form=$SourceForm;acquired=$owned;abandoned=$abandoned;passes=$passes;error=$failure;cap=3221225472;reader_validated=$false;published=$false;next='Separate source/content/link/raster and publication-metadata gates required.'}
 [IO.File]::WriteAllText((Join-Path $outputRoot 'BUILD_RESULT.json'),($r|ConvertTo-Json -Depth 8)+"`n",[Text.UTF8Encoding]::new($false))
}
if($failure){throw $failure}
